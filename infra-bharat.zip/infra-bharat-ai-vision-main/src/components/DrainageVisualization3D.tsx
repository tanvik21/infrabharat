import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Text } from '@react-three/drei';
import { Card } from '@/components/ui/card';

interface PipeSegment {
  start: [number, number, number];
  end: [number, number, number];
  diameter: number;
  status: 'good' | 'warning' | 'critical';
}

const pipeSegments: PipeSegment[] = [
  { start: [-5, -1, 0], end: [5, -1, 0], diameter: 0.3, status: 'good' },
  { start: [5, -1, 0], end: [5, -1, -5], diameter: 0.3, status: 'warning' },
  { start: [-5, -1, 0], end: [-5, -1, -5], diameter: 0.2, status: 'critical' },
  { start: [0, -1, 0], end: [0, -1, -5], diameter: 0.25, status: 'good' },
  { start: [-2, -1, -5], end: [2, -1, -5], diameter: 0.2, status: 'warning' },
];

function Pipe({ segment }: { segment: PipeSegment }) {
  const [x1, y1, z1] = segment.start;
  const [x2, y2, z2] = segment.end;
  
  const length = Math.sqrt(
    Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) + Math.pow(z2 - z1, 2)
  );
  
  const midX = (x1 + x2) / 2;
  const midY = (y1 + y2) / 2;
  const midZ = (z1 + z2) / 2;

  const color = 
    segment.status === 'good' ? '#22c55e' :
    segment.status === 'warning' ? '#eab308' :
    '#ef4444';

  return (
    <mesh position={[midX, midY, midZ]}>
      <cylinderGeometry args={[segment.diameter, segment.diameter, length, 16]} />
      <meshStandardMaterial color={color} metalness={0.5} roughness={0.5} />
    </mesh>
  );
}

function Ground() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]} receiveShadow>
      <planeGeometry args={[20, 20]} />
      <meshStandardMaterial color="#8b7355" />
    </mesh>
  );
}

function Buildings() {
  return (
    <>
      <mesh position={[-3, 1, -3]} castShadow>
        <boxGeometry args={[2, 4, 2]} />
        <meshStandardMaterial color="#94a3b8" />
      </mesh>
      <mesh position={[3, 1.5, -3]} castShadow>
        <boxGeometry args={[2, 5, 2]} />
        <meshStandardMaterial color="#cbd5e1" />
      </mesh>
      <mesh position={[0, 0.5, 3]} castShadow>
        <boxGeometry args={[3, 3, 2]} />
        <meshStandardMaterial color="#64748b" />
      </mesh>
    </>
  );
}

export function DrainageVisualization3D() {
  return (
    <Card className="w-full h-[600px] overflow-hidden">
      <Canvas shadows>
        <PerspectiveCamera makeDefault position={[8, 6, 8]} />
        <OrbitControls 
          enablePan={true}
          enableZoom={true}
          enableRotate={true}
          maxPolarAngle={Math.PI / 2}
        />
        
        <ambientLight intensity={0.5} />
        <directionalLight
          position={[10, 10, 5]}
          intensity={1}
          castShadow
          shadow-mapSize-width={1024}
          shadow-mapSize-height={1024}
        />
        
        <Ground />
        <Buildings />
        
        {pipeSegments.map((segment, index) => (
          <Pipe key={index} segment={segment} />
        ))}
        
        <Text
          position={[0, 3, 0]}
          fontSize={0.5}
          color="#1e293b"
          anchorX="center"
          anchorY="middle"
        >
          Drainage Network
        </Text>

        <Text
          position={[-6, -2.5, 0]}
          fontSize={0.3}
          color="#22c55e"
          anchorX="left"
        >
          Good
        </Text>
        <Text
          position={[-6, -2.5, -2]}
          fontSize={0.3}
          color="#eab308"
          anchorX="left"
        >
          Warning
        </Text>
        <Text
          position={[-6, -2.5, -4]}
          fontSize={0.3}
          color="#ef4444"
          anchorX="left"
        >
          Critical
        </Text>
      </Canvas>
    </Card>
  );
}
