import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Upload, Loader2, CheckCircle, ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface DrainageAnalysisFormProps {
  zones: any[];
  onRecommendationSaved: () => void;
}

interface CurrentSpecs {
  width: string;
  length: string;
  gradient: string;
  material: string;
  condition: string;
}

interface AIRecommendation {
  title: string;
  description: string;
  current_specs: {
    pipe_diameter_mm: number;
    length_m: number;
    gradient_percent: number;
    material: string;
    flow_capacity_lps: number;
    condition_rating: string;
  };
  proposed_specs: {
    pipe_diameter_mm: number;
    length_m: number;
    gradient_percent: number;
    material: string;
    flow_capacity_lps: number;
    additional_features: string[];
  };
  improvements: {
    capacity_increase_percent: number;
    flow_rate_increase_percent: number;
    flood_risk_reduction: string;
  };
  estimated_cost: number;
  estimated_timeline_days: number;
  priority: number;
}

export function DrainageAnalysisForm({ zones, onRecommendationSaved }: DrainageAnalysisFormProps) {
  const { toast } = useToast();
  const [selectedZone, setSelectedZone] = useState<string>("");
  const [photos, setPhotos] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [photoUrls, setPhotoUrls] = useState<string[]>([]);
  const [currentSpecs, setCurrentSpecs] = useState<CurrentSpecs>({
    width: "",
    length: "",
    gradient: "",
    material: "Concrete",
    condition: "fair",
  });
  const [recommendation, setRecommendation] = useState<AIRecommendation | null>(null);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const fileArray = Array.from(e.target.files);
      if (fileArray.length > 5) {
        toast({
          title: "Too many files",
          description: "Maximum 5 photos allowed",
          variant: "destructive",
        });
        return;
      }
      setPhotos(fileArray);
    }
  };

  const uploadPhotos = async () => {
    if (photos.length === 0) return [];

    setUploading(true);
    const urls: string[] = [];

    try {
      for (const photo of photos) {
        const fileExt = photo.name.split(".").pop();
        const fileName = `${selectedZone}/${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;

        const { data, error } = await supabase.storage
          .from("drainage-photos")
          .upload(fileName, photo);

        if (error) throw error;

        const { data: { publicUrl } } = supabase.storage
          .from("drainage-photos")
          .getPublicUrl(data.path);

        urls.push(publicUrl);
      }

      setPhotoUrls(urls);
      toast({
        title: "Photos uploaded",
        description: `${urls.length} photo(s) uploaded successfully`,
      });
      return urls;
    } catch (error: any) {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
      return [];
    } finally {
      setUploading(false);
    }
  };

  const analyzeWithAI = async () => {
    if (!selectedZone) {
      toast({
        title: "Select zone",
        description: "Please select a zone first",
        variant: "destructive",
      });
      return;
    }

    if (!currentSpecs.width || !currentSpecs.length || !currentSpecs.gradient) {
      toast({
        title: "Missing specifications",
        description: "Please fill in all current specifications",
        variant: "destructive",
      });
      return;
    }

    setAnalyzing(true);

    try {
      // Upload photos first if any
      let urls = photoUrls;
      if (photos.length > 0 && photoUrls.length === 0) {
        urls = await uploadPhotos();
      }

      const { data, error } = await supabase.functions.invoke("analyze-drainage", {
        body: {
          zone_id: selectedZone,
          photo_urls: urls,
          current_specs: currentSpecs,
          save_recommendation: false,
        },
      });

      if (error) throw error;

      if (data.error) {
        throw new Error(data.error);
      }

      setRecommendation(data.recommendation);
      toast({
        title: "Analysis complete",
        description: "AI has generated drainage recommendations",
      });
    } catch (error: any) {
      toast({
        title: "Analysis failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const saveRecommendation = async () => {
    if (!recommendation || !selectedZone) return;

    try {
      const { error } = await supabase.functions.invoke("analyze-drainage", {
        body: {
          zone_id: selectedZone,
          photo_urls: photoUrls,
          current_specs: currentSpecs,
          save_recommendation: true,
        },
      });

      if (error) throw error;

      toast({
        title: "Recommendation saved",
        description: "Available for contractor bidding",
      });

      // Reset form
      setSelectedZone("");
      setPhotos([]);
      setPhotoUrls([]);
      setCurrentSpecs({
        width: "",
        length: "",
        gradient: "",
        material: "Concrete",
        condition: "fair",
      });
      setRecommendation(null);
      onRecommendationSaved();
    } catch (error: any) {
      toast({
        title: "Save failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>AI-Powered Drainage Analysis</CardTitle>
          <CardDescription>
            Upload photos and enter current specifications to receive AI-generated improvement recommendations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="zone">Select Zone</Label>
            <select
              id="zone"
              className="w-full p-2 border rounded-md bg-background"
              value={selectedZone}
              onChange={(e) => setSelectedZone(e.target.value)}
            >
              <option value="">Choose a zone...</option>
              {zones.map((zone) => (
                <option key={zone.id} value={zone.id}>
                  {zone.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="photos">Upload Drainage Photos (Max 5)</Label>
            <div className="flex items-center gap-2">
              <Input
                id="photos"
                type="file"
                accept="image/*"
                multiple
                onChange={handlePhotoChange}
                disabled={uploading}
              />
              {photos.length > 0 && (
                <Badge variant="secondary">{photos.length} selected</Badge>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="width">Pipe Diameter (mm)</Label>
              <Input
                id="width"
                type="number"
                placeholder="e.g., 600"
                value={currentSpecs.width}
                onChange={(e) => setCurrentSpecs({ ...currentSpecs, width: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="length">Length (meters)</Label>
              <Input
                id="length"
                type="number"
                placeholder="e.g., 150"
                value={currentSpecs.length}
                onChange={(e) => setCurrentSpecs({ ...currentSpecs, length: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="gradient">Gradient (%)</Label>
              <Input
                id="gradient"
                type="number"
                step="0.1"
                placeholder="e.g., 0.5"
                value={currentSpecs.gradient}
                onChange={(e) => setCurrentSpecs({ ...currentSpecs, gradient: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="material">Material</Label>
              <Input
                id="material"
                placeholder="e.g., Concrete, HDPE"
                value={currentSpecs.material}
                onChange={(e) => setCurrentSpecs({ ...currentSpecs, material: e.target.value })}
              />
            </div>
          </div>

          <Button
            onClick={analyzeWithAI}
            disabled={analyzing || uploading || !selectedZone}
            className="w-full"
          >
            {analyzing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analyzing with AI...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Generate AI Recommendation
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {recommendation && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>{recommendation.title}</CardTitle>
              <Badge variant={recommendation.priority >= 4 ? "destructive" : "secondary"}>
                Priority {recommendation.priority}/5
              </Badge>
            </div>
            <CardDescription>{recommendation.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Before/After Comparison */}
            <div className="grid md:grid-cols-2 gap-4">
              <Card className="border-2">
                <CardHeader>
                  <CardTitle className="text-lg">Current Specifications</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Diameter:</span>
                    <span className="font-medium">{recommendation.current_specs.pipe_diameter_mm} mm</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Length:</span>
                    <span className="font-medium">{recommendation.current_specs.length_m} m</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Gradient:</span>
                    <span className="font-medium">{recommendation.current_specs.gradient_percent}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Material:</span>
                    <span className="font-medium">{recommendation.current_specs.material}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Flow Capacity:</span>
                    <span className="font-medium">{recommendation.current_specs.flow_capacity_lps} L/s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Condition:</span>
                    <Badge variant="outline">{recommendation.current_specs.condition_rating}</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-primary">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <ArrowRight className="h-5 w-5 text-primary" />
                    <CardTitle className="text-lg">Proposed Specifications</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Diameter:</span>
                    <span className="font-medium text-primary">{recommendation.proposed_specs.pipe_diameter_mm} mm</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Length:</span>
                    <span className="font-medium">{recommendation.proposed_specs.length_m} m</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Gradient:</span>
                    <span className="font-medium">{recommendation.proposed_specs.gradient_percent}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Material:</span>
                    <span className="font-medium text-primary">{recommendation.proposed_specs.material}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Flow Capacity:</span>
                    <span className="font-medium text-primary">{recommendation.proposed_specs.flow_capacity_lps} L/s</span>
                  </div>
                  {recommendation.proposed_specs.additional_features?.length > 0 && (
                    <div className="pt-2">
                      <span className="text-muted-foreground text-xs">Additional Features:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {recommendation.proposed_specs.additional_features.map((feature, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Improvements */}
            <Card className="bg-primary/5">
              <CardHeader>
                <CardTitle className="text-lg">Expected Improvements</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-3xl font-bold text-primary">
                    +{recommendation.improvements.capacity_increase_percent}%
                  </div>
                  <div className="text-sm text-muted-foreground">Capacity Increase</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">
                    +{recommendation.improvements.flow_rate_increase_percent}%
                  </div>
                  <div className="text-sm text-muted-foreground">Flow Rate Increase</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary capitalize">
                    {recommendation.improvements.flood_risk_reduction}
                  </div>
                  <div className="text-sm text-muted-foreground">Flood Risk Reduction</div>
                </div>
              </CardContent>
            </Card>

            {/* Cost and Timeline */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <span className="text-muted-foreground">Estimated Cost:</span>
                <span className="text-2xl font-bold">₹{recommendation.estimated_cost.toLocaleString("en-IN")}</span>
              </div>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <span className="text-muted-foreground">Timeline:</span>
                <span className="text-2xl font-bold">{recommendation.estimated_timeline_days} days</span>
              </div>
            </div>

            <Button onClick={saveRecommendation} className="w-full" size="lg">
              <CheckCircle className="mr-2 h-5 w-5" />
              Approve & Save for Contractor Bidding
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
