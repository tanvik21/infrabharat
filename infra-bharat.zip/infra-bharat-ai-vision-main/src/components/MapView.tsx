import { useEffect, useRef, useState } from "react";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import { Card } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

// Get Mapbox token from environment (configured in Supabase secrets)
const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_API_KEY;
if (MAPBOX_TOKEN) {
  mapboxgl.accessToken = MAPBOX_TOKEN;
}

interface MapViewProps {
  zones?: any[];
  reports?: any[];
  onZoneClick?: (zone: any) => void;
  onReportClick?: (report: any) => void;
  center?: [number, number];
  zoom?: number;
}

export default function MapView({
  zones = [],
  reports = [],
  onZoneClick,
  onReportClick,
  center = [77.5946, 12.9716], // Bangalore coordinates
  zoom = 11,
}: MapViewProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState(false);

  // Check if API key is configured
  if (!MAPBOX_TOKEN) {
    return (
      <Card className="h-full w-full p-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Mapbox API key not configured. Please add your Mapbox API key in the backend secrets to enable map functionality.
          </AlertDescription>
        </Alert>
      </Card>
    );
  }

  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: "mapbox://styles/mapbox/streets-v12",
        center: center,
        zoom: zoom,
      });

      // Add navigation controls
      map.current.addControl(new mapboxgl.NavigationControl(), "top-right");
      
      // Add geolocate control
      map.current.addControl(
        new mapboxgl.GeolocateControl({
          positionOptions: {
            enableHighAccuracy: true
          },
          trackUserLocation: true,
          showUserHeading: true
        }),
        "top-right"
      );

      map.current.on("load", () => {
        setMapLoaded(true);
      });

      map.current.on("error", (e) => {
        console.error("Map error:", e);
        setMapError(true);
      });

    } catch (error) {
      console.error("Failed to initialize map:", error);
      setMapError(true);
    }

    return () => {
      map.current?.remove();
    };
  }, []);

  // Add zones to map
  useEffect(() => {
    if (!map.current || !mapLoaded || zones.length === 0) return;

    // Add zones source and layer
    if (!map.current.getSource("zones")) {
      map.current.addSource("zones", {
        type: "geojson",
        data: {
          type: "FeatureCollection",
          features: zones.map((zone) => ({
            type: "Feature",
            properties: {
              id: zone.id,
              name: zone.name,
              flood_risk: zone.flood_risk_score,
              heat_risk: zone.heat_risk_score,
            },
            geometry: zone.geometry,
          })),
        },
      });

      map.current.addLayer({
        id: "zones-fill",
        type: "fill",
        source: "zones",
        paint: {
          "fill-color": [
            "interpolate",
            ["linear"],
            ["get", "flood_risk"],
            0, "#00ff00",
            0.5, "#ffff00",
            1, "#ff0000",
          ],
          "fill-opacity": 0.4,
        },
      });

      map.current.addLayer({
        id: "zones-outline",
        type: "line",
        source: "zones",
        paint: {
          "line-color": "#000",
          "line-width": 2,
        },
      });

      // Add click handler for zones
      map.current.on("click", "zones-fill", (e) => {
        if (e.features && e.features.length > 0 && onZoneClick) {
          const feature = e.features[0];
          onZoneClick(feature.properties);
        }
      });

      map.current.on("mouseenter", "zones-fill", () => {
        if (map.current) {
          map.current.getCanvas().style.cursor = "pointer";
        }
      });

      map.current.on("mouseleave", "zones-fill", () => {
        if (map.current) {
          map.current.getCanvas().style.cursor = "";
        }
      });
    }
  }, [mapLoaded, zones, onZoneClick]);

  // Add reports to map
  useEffect(() => {
    if (!map.current || !mapLoaded || reports.length === 0) return;

    // Add reports source and layer
    if (!map.current.getSource("reports")) {
      map.current.addSource("reports", {
        type: "geojson",
        data: {
          type: "FeatureCollection",
          features: reports.map((report) => ({
            type: "Feature",
            properties: {
              id: report.id,
              title: report.title,
              status: report.status,
              severity: report.severity,
            },
            geometry: report.location,
          })),
        },
      });

      map.current.addLayer({
        id: "reports",
        type: "circle",
        source: "reports",
        paint: {
          "circle-radius": 8,
          "circle-color": [
            "match",
            ["get", "status"],
            "pending", "#ff0000",
            "in_progress", "#ffaa00",
            "resolved", "#00ff00",
            "#666666",
          ],
          "circle-stroke-width": 2,
          "circle-stroke-color": "#fff",
        },
      });

      // Add click handler for reports
      map.current.on("click", "reports", (e) => {
        if (e.features && e.features.length > 0 && onReportClick) {
          const feature = e.features[0];
          onReportClick(feature.properties);
        }
      });

      map.current.on("mouseenter", "reports", () => {
        if (map.current) {
          map.current.getCanvas().style.cursor = "pointer";
        }
      });

      map.current.on("mouseleave", "reports", () => {
        if (map.current) {
          map.current.getCanvas().style.cursor = "";
        }
      });
    }
  }, [mapLoaded, reports, onReportClick]);

  if (mapError) {
    return (
      <Card className="h-full w-full p-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Failed to load map. Please check your internet connection and Mapbox API key configuration.
          </AlertDescription>
        </Alert>
      </Card>
    );
  }

  return (
    <Card className="h-full w-full overflow-hidden">
      <div ref={mapContainer} className="h-full w-full min-h-[480px]" style={{ position: 'relative', zIndex: 1 }} />
    </Card>
  );
}
