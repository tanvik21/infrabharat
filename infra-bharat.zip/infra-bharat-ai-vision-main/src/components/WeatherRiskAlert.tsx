import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CloudRain, AlertTriangle, RefreshCw, Droplets } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface WeatherData {
  current: {
    temperature: number;
    precipitation: number;
    humidity: number;
  };
  forecast: {
    next_3_days_rainfall: number;
    max_probability: number;
  };
  waterlogging_risk: {
    score: number;
    level: string;
    message: string;
  };
  high_risk_zones: Array<{
    id: string;
    name: string;
    flood_risk_score: number;
  }>;
  preventive_recommendations: Array<{
    zone_id: string;
    zone_name: string;
    recommendation: string;
  }>;
}

export function WeatherRiskAlert() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchWeather = async () => {
    setLoading(true);
    try {
      // Default to Bangalore coordinates
      const latitude = 12.9716;
      const longitude = 77.5946;

      const { data, error } = await supabase.functions.invoke("weather-forecast", {
        body: { latitude, longitude },
      });

      if (error) throw error;
      setWeather(data);
    } catch (error: any) {
      toast({
        title: "Weather fetch failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeather();
    // Refresh every 30 minutes
    const interval = setInterval(fetchWeather, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  if (loading || !weather) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CloudRain className="h-5 w-5" />
            Loading Weather Data...
          </CardTitle>
        </CardHeader>
      </Card>
    );
  }

  const riskColor =
    weather.waterlogging_risk.level === "high"
      ? "destructive"
      : weather.waterlogging_risk.level === "medium"
      ? "secondary"
      : "default";

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <CloudRain className="h-5 w-5" />
              Weather & Waterlogging Risk
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={fetchWeather}>
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
          <CardDescription>Real-time weather forecast and risk analysis</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{weather.current.temperature}°C</div>
              <div className="text-sm text-muted-foreground">Temperature</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{weather.current.precipitation}mm</div>
              <div className="text-sm text-muted-foreground">Current Rain</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{weather.current.humidity}%</div>
              <div className="text-sm text-muted-foreground">Humidity</div>
            </div>
          </div>

          <Alert variant={riskColor === "destructive" ? "destructive" : "default"}>
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle className="flex items-center gap-2">
              Waterlogging Risk: <Badge variant={riskColor}>{weather.waterlogging_risk.level.toUpperCase()}</Badge>
            </AlertTitle>
            <AlertDescription>{weather.waterlogging_risk.message}</AlertDescription>
          </Alert>

          <div className="border-t pt-4">
            <div className="flex items-center gap-2 mb-2">
              <Droplets className="h-4 w-4 text-blue-500" />
              <span className="font-medium">3-Day Forecast</span>
            </div>
            <div className="text-sm space-y-1">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Expected Rainfall:</span>
                <span className="font-medium">{weather.forecast.next_3_days_rainfall.toFixed(1)}mm</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Rain Probability:</span>
                <span className="font-medium">{weather.forecast.max_probability}%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {weather.high_risk_zones.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">High-Risk Zones</CardTitle>
            <CardDescription>Zones requiring immediate attention</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {weather.high_risk_zones.map((zone) => (
              <div key={zone.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <div className="font-medium">{zone.name}</div>
                  <div className="text-sm text-muted-foreground">
                    Flood Risk: {(zone.flood_risk_score * 100).toFixed(0)}%
                  </div>
                </div>
                <Badge variant="destructive">High Risk</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {weather.preventive_recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">AI Preventive Recommendations</CardTitle>
            <CardDescription>Automated recommendations for high-risk zones</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {weather.preventive_recommendations.map((rec, idx) => (
              <div key={idx} className="p-4 bg-muted rounded-lg space-y-2">
                <div className="font-medium flex items-center gap-2">
                  <Badge variant="outline">{rec.zone_name}</Badge>
                </div>
                <p className="text-sm">{rec.recommendation}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
