import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/components/language-provider";
import { LanguageSelector } from "@/components/language-selector";
import { ThemeToggle } from "@/components/theme-toggle";
import { NotificationBell } from "@/components/NotificationBell";
import MapView from "@/components/MapView";
import { DrainageVisualization3D } from "@/components/DrainageVisualization3D";
import { DrainageAnalysisForm } from "@/components/DrainageAnalysisForm";
import { LogOut, TrendingUp, AlertTriangle, MapPin, IndianRupee, FileText } from "lucide-react";

export default function OfficerDashboard() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { t } = useLanguage();
  const [user, setUser] = useState<any>(null);
  const [zones, setZones] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [selectedZone, setSelectedZone] = useState<any>(null);
  const [selectedZoneId, setSelectedZoneId] = useState<string>("");
  const [mapCenter, setMapCenter] = useState<[number, number]>([77.5946, 12.9716]);
  const [loading, setLoading] = useState(true);
  const mapRef = useRef<any>(null);

  useEffect(() => {
    checkAuth();
    fetchDashboardData();
  }, []);

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    // Check if user has officer or admin role
    const { data: roleData } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    if (roleData?.role !== "official") {
      navigate("/citizen-dashboard");
      return;
    }

    setUser(user);
  };

  const fetchDashboardData = async () => {
    try {
      const [zonesResult, reportsResult, recommendationsResult] = await Promise.all([
        supabase.from("zones").select("*"),
        supabase.from("reports").select("*").order("created_at", { ascending: false }),
        supabase.from("ai_recommendations").select("*, zones(name)").order("priority", { ascending: false }),
      ]);

      if (zonesResult.data) setZones(zonesResult.data);
      if (reportsResult.data) setReports(reportsResult.data);
      if (recommendationsResult.data) setRecommendations(recommendationsResult.data);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  const handleZoneSelect = (zoneId: string) => {
    const zone = zones.find(z => z.id === zoneId);
    if (zone) {
      setSelectedZoneId(zoneId);
      setSelectedZone(zone);
      
      // Extract centroid from metadata
      const centroid = zone.metadata?.centroid;
      if (centroid) {
        setMapCenter([centroid.lng, centroid.lat]);
      }
    }
  };

  const handleZoneClick = (zoneProps: any) => {
    // Find zone by id from properties
    const zone = zones.find(z => z.id === zoneProps.id);
    if (zone) {
      setSelectedZoneId(zone.id);
      setSelectedZone(zone);
    }
  };

  const generateRecommendation = async (zoneId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke("generate-recommendations", {
        body: { zone_id: zoneId },
      });

      if (error) throw error;

      toast({
        title: "Recommendation Generated",
        description: "AI recommendation has been generated for this zone.",
      });

      fetchDashboardData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold">InfraBharat - Officer Dashboard</h1>
          <div className="flex items-center gap-4">
            <NotificationBell />
            <LanguageSelector />
            <ThemeToggle />
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              {t("logout")}
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Zones</CardTitle>
              <MapPin className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{zones.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Reports</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {reports.filter((r) => r.status !== "resolved").length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">AI Recommendations</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{recommendations.length}</div>
            </CardContent>
          </Card>
        </div>

        {/* Zone Selection */}
        <Card>
          <CardHeader>
            <CardTitle>Zone Selection</CardTitle>
            <CardDescription>Select a zone to view on map and populate analysis form</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="zone-select">Select Zone</Label>
              <select
                id="zone-select"
                className="w-full p-2 border rounded-md bg-background"
                value={selectedZoneId}
                onChange={(e) => handleZoneSelect(e.target.value)}
              >
                <option value="">Choose a zone...</option>
                {zones.map((zone) => (
                  <option key={zone.id} value={zone.id}>
                    {zone.name} - Ward {zone.ward_number} (Flood Risk: {((zone.flood_risk_score || 0) * 100).toFixed(0)}%)
                  </option>
                ))}
              </select>
            </div>
            {selectedZone && (
              <div className="mt-4 p-4 border rounded-lg space-y-2">
                <h4 className="font-semibold">{selectedZone.name}</h4>
                <p className="text-sm text-muted-foreground">{selectedZone.metadata?.description}</p>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Population:</span>
                    <span className="ml-2 font-medium">{selectedZone.population?.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Area:</span>
                    <span className="ml-2 font-medium">{selectedZone.area_sqkm} sq km</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Flood Risk:</span>
                    <Badge variant={selectedZone.flood_risk_score > 0.7 ? "destructive" : "secondary"}>
                      {((selectedZone.flood_risk_score || 0) * 100).toFixed(0)}%
                    </Badge>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Last Inspection:</span>
                    <span className="ml-2 font-medium">{selectedZone.metadata?.last_inspection || "N/A"}</span>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Tabs defaultValue="map" className="space-y-4">
          <TabsList>
            <TabsTrigger value="map">Map View</TabsTrigger>
            <TabsTrigger value="analysis">AI Drainage Analysis</TabsTrigger>
            <TabsTrigger value="3d">3D Drainage</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="map" className="space-y-4">
            <div className="h-[600px]">
              <MapView
                zones={zones}
                reports={reports}
                onZoneClick={handleZoneClick}
                center={mapCenter}
                zoom={selectedZoneId ? 14 : 11}
              />
            </div>
          </TabsContent>

          <TabsContent value="analysis" className="space-y-4">
            {!selectedZoneId && (
              <Card>
                <CardContent className="pt-6">
                  <p className="text-center text-muted-foreground">
                    Please select a zone above to populate the drainage analysis form
                  </p>
                </CardContent>
              </Card>
            )}
            <DrainageAnalysisForm zones={zones} onRecommendationSaved={fetchDashboardData} />
          </TabsContent>

          <TabsContent value="3d" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>3D Drainage Infrastructure Visualization</CardTitle>
                <CardDescription>
                  Interactive 3D view of drainage network and proposed improvements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <DrainageVisualization3D />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <div className="grid gap-4">
              {reports.map((report) => (
                <Card key={report.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{report.title}</CardTitle>
                      <Badge
                        variant={
                          report.status === "resolved"
                            ? "default"
                            : report.status === "in_progress"
                            ? "secondary"
                            : "destructive"
                        }
                      >
                        {report.status}
                      </Badge>
                    </div>
                    <CardDescription>{report.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      {report.address || "Location available on map"}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-4">
            <Card className="mb-4">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  AI Recommendations
                </CardTitle>
                <CardDescription>
                  View all AI-generated drainage improvement recommendations. Only officials can access these.
                </CardDescription>
              </CardHeader>
            </Card>
            <div className="grid gap-4">
              {recommendations.length === 0 ? (
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-center text-muted-foreground">
                      No recommendations yet. Generate recommendations from the AI Drainage Analysis tab.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                recommendations.map((rec) => (
                  <Card key={rec.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{rec.title}</CardTitle>
                        <Badge variant={rec.priority >= 4 ? "destructive" : "secondary"}>
                          Priority {rec.priority}/5
                        </Badge>
                      </div>
                      <CardDescription>{rec.zones?.name || "Zone N/A"}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm">{rec.description}</p>
                      <div className="grid grid-cols-2 gap-4">
                        {rec.estimated_cost && (
                          <div className="flex items-center gap-2">
                            <IndianRupee className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <p className="text-xs text-muted-foreground">Estimated Cost</p>
                              <p className="font-semibold">
                                ₹{rec.estimated_cost.toLocaleString("en-IN")}
                              </p>
                            </div>
                          </div>
                        )}
                        {rec.estimated_timeline_days && (
                          <div>
                            <p className="text-xs text-muted-foreground">Timeline</p>
                            <p className="font-semibold">{rec.estimated_timeline_days} days</p>
                          </div>
                        )}
                      </div>
                      <Badge variant="outline" className="mt-2">
                        Status: {rec.status}
                      </Badge>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
