
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { LanguageSelector } from "@/components/language-selector";
import { ThemeToggle } from "@/components/theme-toggle";
import { NotificationBell } from "@/components/NotificationBell";
import { CitizenChatbot } from "@/components/CitizenChatbot";
import { AlertCircle, CheckCircle, Clock, FileText, LogOut, MapPin } from "lucide-react";

const CitizenDashboard = () => {
  const [complaint, setComplaint] = useState("");
  const [location, setLocation] = useState("");
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleComplaintSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (complaint && location) {
      toast({
        title: "Complaint Submitted",
        description: "Your complaint has been registered. Complaint ID: #IB2024001",
      });
      setComplaint("");
      setLocation("");
    }
  };

  const mockComplaints = [
    { id: "#IB2024001", status: "In Progress", location: "MG Road, Bangalore", date: "2024-01-15" },
    { id: "#IB2024002", status: "Resolved", location: "CP Metro Station, Delhi", date: "2024-01-10" },
    { id: "#IB2024003", status: "Under Review", location: "Bandra West, Mumbai", date: "2024-01-12" },
  ];

  const safeRoutes = [
    { from: "Connaught Place", to: "India Gate", status: "Clear", eta: "25 mins" },
    { from: "Karol Bagh", to: "Rajouri Garden", status: "Moderate Risk", eta: "35 mins" },
    { from: "Dwarka", to: "Gurgaon", status: "High Risk", eta: "Avoid" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-infra-green-500 to-infra-blue-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">IB</span>
              </div>
              <h1 className="text-xl font-bold text-gray-900">Citizen Dashboard</h1>
            </div>
            <div className="flex items-center space-x-3">
              <NotificationBell />
              <LanguageSelector />
              <ThemeToggle />
              <Button 
                variant="outline" 
                onClick={() => navigate("/")}
                className="border-gray-300"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome, Citizen!</h2>
          <p className="text-gray-600">Report issues and access safe route recommendations</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Report Complaint */}
          <Card className="shadow-lg border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>📝</span>
                <span>Report Water Logging Issue</span>
              </CardTitle>
              <CardDescription>
                Help us identify and resolve drainage problems in your area
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleComplaintSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    placeholder="Enter specific location (e.g., MG Road, Bangalore)"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="complaint">Issue Description</Label>
                  <Textarea
                    id="complaint"
                    placeholder="Describe the water logging issue, severity, and any other relevant details..."
                    value={complaint}
                    onChange={(e) => setComplaint(e.target.value)}
                    rows={4}
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-infra-green-600 hover:bg-infra-green-700"
                >
                  Submit Complaint
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Safe Routes */}
          <Card className="shadow-lg border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>🗺️</span>
                <span>Safe Route Recommendations</span>
              </CardTitle>
              <CardDescription>
                Real-time route suggestions to avoid water logged areas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {safeRoutes.map((route, index) => (
                  <div key={index} className="p-3 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <div className="text-sm font-medium">
                        {route.from} → {route.to}
                      </div>
                      <Badge 
                        variant={route.status === "Clear" ? "default" : 
                               route.status === "Moderate Risk" ? "secondary" : "destructive"}
                        className={route.status === "Clear" ? "bg-green-100 text-green-800" : ""}
                      >
                        {route.status}
                      </Badge>
                    </div>
                    <div className="text-xs text-gray-500">ETA: {route.eta}</div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4">
                Get Custom Route
              </Button>
            </CardContent>
          </Card>

          {/* My Complaints */}
          <Card className="shadow-lg border-0 lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>📋</span>
                <span>My Complaints Status</span>
              </CardTitle>
              <CardDescription>
                Track the progress of your submitted complaints
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockComplaints.map((complaint, index) => (
                  <div key={index} className="flex justify-between items-center p-4 border rounded-lg">
                    <div>
                      <div className="font-medium">{complaint.id}</div>
                      <div className="text-sm text-gray-600">{complaint.location}</div>
                      <div className="text-xs text-gray-500">Submitted: {complaint.date}</div>
                    </div>
                    <Badge 
                      variant={complaint.status === "Resolved" ? "default" : "secondary"}
                      className={complaint.status === "Resolved" ? "bg-green-100 text-green-800" : ""}
                    >
                      {complaint.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      <CitizenChatbot />
    </div>
  );
};

export default CitizenDashboard;
