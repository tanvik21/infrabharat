import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { LanguageSelector } from "@/components/language-selector";
import { ThemeToggle } from "@/components/theme-toggle";
import { NotificationBell } from "@/components/NotificationBell";
import { FileText, DollarSign, Clock, TrendingUp, LogOut } from "lucide-react";

export default function ContractorDashboard() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [myBids, setMyBids] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRec, setSelectedRec] = useState<any>(null);
  const [bidAmount, setBidAmount] = useState("");
  const [estimatedDays, setEstimatedDays] = useState("");
  const [proposalDetails, setProposalDetails] = useState("");

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    // Contractors are now considered officials
    if (roles?.role !== "official") {
      toast({
        title: "Access Denied",
        description: "This dashboard is only for officials with contractor access",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    setUser(user);
    fetchData(user.id);
  };

  const fetchData = async (userId: string) => {
    setLoading(true);

    // Fetch available recommendations
    const { data: recs } = await supabase
      .from("ai_recommendations")
      .select(`
        *,
        zones(name, ward_number)
      `)
      .eq("status", "pending")
      .order("created_at", { ascending: false });

    // Fetch contractor's bids
    const { data: bids } = await supabase
      .from("contractor_bids")
      .select(`
        *,
        ai_recommendations(title, estimated_cost, zones(name))
      `)
      .eq("contractor_id", userId)
      .order("submitted_at", { ascending: false });

    setRecommendations(recs || []);
    setMyBids(bids || []);
    setLoading(false);
  };

  const handleSubmitBid = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedRec || !user) return;

    const { error } = await supabase
      .from("contractor_bids")
      .insert({
        contractor_id: user.id,
        recommendation_id: selectedRec.id,
        bid_amount: parseFloat(bidAmount),
        estimated_days: parseInt(estimatedDays),
        proposal_details: proposalDetails,
      });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to submit bid",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Success",
      description: "Bid submitted successfully",
    });

    setSelectedRec(null);
    setBidAmount("");
    setEstimatedDays("");
    setProposalDetails("");
    fetchData(user.id);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground">Contractor Dashboard</h1>
          <div className="flex items-center gap-2">
            <NotificationBell />
            <LanguageSelector />
            <ThemeToggle />
            <Button onClick={handleLogout} variant="ghost" size="sm">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Bids</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{myBids.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Accepted</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {myBids.filter(b => b.status === 'accepted').length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <Clock className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">
                {myBids.filter(b => b.status === 'pending').length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Opportunities</CardTitle>
              <DollarSign className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{recommendations.length}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="opportunities">
          <TabsList>
            <TabsTrigger value="opportunities">Available Projects</TabsTrigger>
            <TabsTrigger value="mybids">My Bids</TabsTrigger>
          </TabsList>

          <TabsContent value="opportunities" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {recommendations.map((rec) => (
                <Card key={rec.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle>{rec.title}</CardTitle>
                    <CardDescription>
                      {rec.zones?.name} - Ward {rec.zones?.ward_number}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{rec.description}</p>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm font-medium">Estimated Cost</div>
                        <div className="text-lg font-bold text-green-600">
                          ₹{rec.estimated_cost?.toLocaleString()}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm font-medium">Timeline</div>
                        <div className="text-lg font-bold text-blue-600">
                          {rec.estimated_timeline_days} days
                        </div>
                      </div>
                    </div>

                    <Badge variant={rec.priority === 1 ? "destructive" : "secondary"}>
                      Priority {rec.priority}
                    </Badge>

                    <Button 
                      onClick={() => setSelectedRec(rec)}
                      className="w-full"
                    >
                      Submit Bid
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="mybids" className="space-y-4">
            {myBids.map((bid) => (
              <Card key={bid.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{bid.ai_recommendations?.title}</CardTitle>
                    <Badge 
                      variant={
                        bid.status === 'accepted' ? 'default' :
                        bid.status === 'rejected' ? 'destructive' :
                        'secondary'
                      }
                    >
                      {bid.status}
                    </Badge>
                  </div>
                  <CardDescription>
                    {bid.ai_recommendations?.zones?.name}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <div className="text-sm text-muted-foreground">Bid Amount</div>
                      <div className="text-lg font-bold">₹{bid.bid_amount?.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Estimated Days</div>
                      <div className="text-lg font-bold">{bid.estimated_days}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Submitted</div>
                      <div className="text-sm">{new Date(bid.submitted_at).toLocaleDateString()}</div>
                    </div>
                  </div>
                  {bid.proposal_details && (
                    <div className="mt-4">
                      <div className="text-sm font-medium">Proposal Details</div>
                      <p className="text-sm text-muted-foreground mt-1">{bid.proposal_details}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>

        {/* Bid Submission Modal */}
        {selectedRec && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-2xl">
              <CardHeader>
                <CardTitle>Submit Bid: {selectedRec.title}</CardTitle>
                <CardDescription>
                  Estimated Cost: ₹{selectedRec.estimated_cost?.toLocaleString()} | 
                  Timeline: {selectedRec.estimated_timeline_days} days
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitBid} className="space-y-4">
                  <div>
                    <Label htmlFor="bidAmount">Your Bid Amount (₹)</Label>
                    <Input
                      id="bidAmount"
                      type="number"
                      value={bidAmount}
                      onChange={(e) => setBidAmount(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="estimatedDays">Estimated Days</Label>
                    <Input
                      id="estimatedDays"
                      type="number"
                      value={estimatedDays}
                      onChange={(e) => setEstimatedDays(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="proposalDetails">Proposal Details</Label>
                    <Textarea
                      id="proposalDetails"
                      value={proposalDetails}
                      onChange={(e) => setProposalDetails(e.target.value)}
                      rows={4}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit" className="flex-1">Submit Bid</Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setSelectedRec(null)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
