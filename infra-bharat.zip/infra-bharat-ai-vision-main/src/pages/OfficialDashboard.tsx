import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { ThemeToggle } from "@/components/theme-toggle";
import { LanguageSelector } from "@/components/language-selector";
import { NotificationBell } from "@/components/NotificationBell";
import { DrainageAnalysisForm } from "@/components/DrainageAnalysisForm";
import { WeatherRiskAlert } from "@/components/WeatherRiskAlert";
import { useLanguage } from "@/components/language-provider";
import MapView from "@/components/MapView";
import { DrainageVisualization3D } from "@/components/DrainageVisualization3D";
import { LogOut, TrendingUp, AlertTriangle, MapPin, IndianRupee } from "lucide-react";

export default function OfficialDashboard() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { t } = useLanguage();
  const [user, setUser] = useState<any>(null);
  const [zones, setZones] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [selectedZone, setSelectedZone] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
    fetchDashboardData();
  }, []);

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data: roleData } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    if (roleData?.role !== "official") {
      navigate("/citizen-dashboard");
      return;
    }

    setUser(user);
  };

  const fetchDashboardData = async () => {
    try {
      const [zonesResult, reportsResult, recommendationsResult] = await Promise.all([
        supabase.from("zones").select("*"),
        supabase.from("reports").select("*").order("created_at", { ascending: false }),
        supabase.from("ai_recommendations").select("*, zones(name)").order("priority", { ascending: false }),
      ]);

      if (zonesResult.data) setZones(zonesResult.data);
      if (reportsResult.data) setReports(reportsResult.data);
      if (recommendationsResult.data) setRecommendations(recommendationsResult.data);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  const handleZoneClick = (zone: any) => {
    setSelectedZone(zone);
  };

  if (loading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }


  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold">InfraBharat - Officer Dashboard</h1>
          <div className="flex items-center gap-4">
            <NotificationBell />
            <LanguageSelector />
            <ThemeToggle />
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              {t("logout")}
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Zones</CardTitle>
              <MapPin className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{zones.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Reports</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {reports.filter((r) => r.status !== "resolved").length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">AI Recommendations</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{recommendations.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Resolution Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {reports.length > 0 
                  ? Math.round((reports.filter(r => r.status === "resolved").length / reports.length) * 100)
                  : 0}%
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="weather" className="space-y-4">
          <TabsList>
            <TabsTrigger value="weather">Weather & Risk</TabsTrigger>
            <TabsTrigger value="analysis">AI Drainage Analysis</TabsTrigger>
            <TabsTrigger value="map">Map View</TabsTrigger>
            <TabsTrigger value="3d">3D Drainage</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="weather" className="space-y-4">
            <WeatherRiskAlert />
          </TabsContent>

          <TabsContent value="analysis" className="space-y-4">
            <DrainageAnalysisForm zones={zones} onRecommendationSaved={fetchDashboardData} />
          </TabsContent>

          <TabsContent value="map" className="space-y-4">
            <div className="h-[600px]">
              <MapView
                zones={zones}
                reports={reports}
                onZoneClick={handleZoneClick}
              />
            </div>
            {selectedZone && (
              <Card>
                <CardHeader>
                  <CardTitle>{selectedZone.name}</CardTitle>
                  <CardDescription>Zone Details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span>Flood Risk:</span>
                    <Badge variant={selectedZone.flood_risk_score > 0.7 ? "destructive" : "secondary"}>
                      {(selectedZone.flood_risk_score * 100).toFixed(0)}%
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="3d" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>3D Drainage Infrastructure</CardTitle>
                <CardDescription>
                  Interactive 3D view of drainage network
                </CardDescription>
              </CardHeader>
              <CardContent>
                <DrainageVisualization3D />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <div className="grid gap-4">
              {reports.map((report) => (
                <Card key={report.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{report.title}</CardTitle>
                      <Badge
                        variant={
                          report.status === "resolved"
                            ? "default"
                            : report.status === "in_progress"
                            ? "secondary"
                            : "destructive"
                        }
                      >
                        {report.status}
                      </Badge>
                    </div>
                    <CardDescription>{report.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      {report.address || "Location available on map"}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-4">
            <div className="grid gap-4">
              {recommendations.map((rec) => (
                <Card key={rec.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{rec.title}</CardTitle>
                      <Badge>Priority {rec.priority}</Badge>
                    </div>
                    <CardDescription>{rec.zones?.name}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm">{rec.description}</p>
                    {rec.estimated_cost && (
                      <div className="flex items-center gap-2">
                        <IndianRupee className="h-4 w-4" />
                        <span className="font-semibold">
                          ₹{rec.estimated_cost.toLocaleString("en-IN")}
                        </span>
                      </div>
                    )}
                    {rec.estimated_timeline_days && (
                      <div className="text-sm text-muted-foreground">
                        Estimated timeline: {rec.estimated_timeline_days} days
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
